# JS
npm init
npm -i
npm -i express mongoose cors body-parser
npm start

