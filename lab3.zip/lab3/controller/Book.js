const Book = require("../model/Book");

const getBooks = async (req, res, next) => {
	let books;

	try {
		books = await Book.find();
	} catch (err) {
		return res.send(err);
	}

	return res.json({ books });
};

const postBook = async (req, res, next) => {
	let book = req.body;

	const newBook = new Book({
		ISBN: book.ISBN,
		price: book.price,
		name: book.name,
		edition: book.edition,
		isInStock: book.isInStock,
	});

	try {
		await newBook.save();
	} catch (err) {
		return res.send(err);
	}

	return res.json({ newBook });
};

const deleteBook = async (req, res, next) => {
	const id = req.params.id;

	try {
		await Book.findOneAndDelete({ ISBN: id });
	} catch (err) {
		return res.send(err);
	}

	res.send("Book Deleted Succesfully");
};

const updateBook = async (req, res, next) => {
	const id = req.params.id;
	let book = req.body;
	let updatedBook;

	try {
		updatedBook = await Book.findOneAndUpdate(
			{ ISBN: id },
			{
				ISBN: book.ISBN,
				name: book.name,
				price: book.price,
				edition: book.edition,
				isInStock: book.isInStock,
			},
			{ new: true }
		);
	} catch (err) {
		return res.send(err);
	}

	res.json({ updatedBook });
};

module.exports = { getBooks, postBook, deleteBook, updateBook };
