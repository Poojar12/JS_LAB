const mongoose = require("mongoose");

const bookSchema = mongoose.Schema({
	ISBN: Number,
	price: Number,
	name: String,
	edition: Number,
	isInStock: Boolean,
});

const Book = mongoose.model("Book", bookSchema);

module.exports = Book;
