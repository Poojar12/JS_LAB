package com.example.program5_practice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText editTextUsername;
    EditText editTextPassword;
    Button loginButton;
    Button registerButton;
    DbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextPassword = findViewById(R.id.editTextPassword);
        editTextUsername = findViewById(R.id.editTextUsername);
        loginButton = findViewById(R.id.loginButton);
        registerButton = findViewById(R.id.registerButton);

        dbHelper = new DbHelper(this);
        dbHelper.addUser(new User("user","password"));

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usernameText = editTextUsername.getText().toString();
                String passwordText = editTextPassword.getText().toString();

                int userExists = dbHelper.checkUser(new User(usernameText,passwordText));

                if(userExists == -1){
                    Toast.makeText(getApplicationContext(), "User does not exist", Toast.LENGTH_SHORT).show();

                }else{
                    Toast.makeText(getApplicationContext(), "User  exists", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this,LoggedInActivity.class);
                    startActivity(intent);
                }
            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usernameText = editTextUsername.getText().toString();
                String passwordText = editTextPassword.getText().toString();
                dbHelper.addUser(new User(usernameText,passwordText));
                Toast.makeText(getApplicationContext(), "User Added", Toast.LENGTH_SHORT).show();
            }
        });

    }
}